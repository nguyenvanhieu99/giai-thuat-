//Bai 1: dua ra xau nhi phan ke tiep
#include <bits/stdc++.h>
#define MAX 1000
using namespace std;
//sinh xau nhi phan tiep theo
void Next_Bits_String(char X[]) {
	int n = strlen(X);	
	int i = n-1;//duyet tu phai qua trai
	while(i>=0 && X[i]=='1') { //lap neu X[i]==1
		X[i]='0'; i--; //dat X[i]=0
	}
	if(i>=0) X[i] ='1';//phan tu bang 0 dau tien thiet lap la 1	
}
int main(void) {
	int T; char X[MAX];cin>>T;
	while(T--){
		cin>>X;
		Next_Bits_String(X);
		cout<<X<<endl;
	}
}
